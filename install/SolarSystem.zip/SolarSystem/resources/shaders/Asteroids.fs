#version 330 core
out vec4 FragColor;

in vec2 TexCoords;

uniform sampler2D texture1;
uniform sampler2D texture2;
uniform float alpha = 0.5;

void main()
{
     // FragColor = texture(texture1, TexCoords);
	 FragColor = mix(texture(texture1, TexCoords), texture(texture2, TexCoords), alpha);
}